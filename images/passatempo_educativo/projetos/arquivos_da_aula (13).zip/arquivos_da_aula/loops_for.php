<html>

<head>
    <meta charset="UTF-8">
    <title>Curso PHP</title>
</head>

<body>
    <?php
    /* 
    $x = 1;
    while ($x < 10){

    }

    do {

    }while($x <10);
    */

    // for($x = 1; $x <= 10; $x++){
    //     echo "$x <br/>";
    // }

    // for ($x = 11; true; $x++) {

    //     if ($x >= 20) {
    //         break;
    //     }
    //     echo "$x <br/>";
    // }

    // for ($x = 10; true; $x--) {

    //     if ($x == 0) {
    //         break;
    //     }
    //     echo "$x <br/>";
    // }

    for ($x = 10; $x > 0; $x--) {

        //break
        //continue
        echo "$x <br/>";
    }
    ?>
</body>

</html>