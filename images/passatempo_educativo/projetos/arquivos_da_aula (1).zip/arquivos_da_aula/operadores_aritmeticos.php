<html>

<head>
    <meta charset="UTF-8">
    <title>Curso PHP</title>
</head>

<body>
    <?php

    $num1 = 13;
    $num2 = 4;

    echo "A soma entre $num1 e $num2 é " . ($num1 + $num2);
    echo "<br />";
    echo "A subtracao entre $num1 e $num2 é " . ($num1 - $num2);
    echo "<br />";
    echo "A multiplicacão entre $num1 e $num2 é " . ($num1 * $num2);
    echo "<br />";
    echo "A divisão entre $num1 e $num2 é " . ($num1 / $num2);
    echo "<br />";
    echo "O módulo entre $num1 e $num2 é " . ($num1 % $num2);
    ?>
</body>

</html>