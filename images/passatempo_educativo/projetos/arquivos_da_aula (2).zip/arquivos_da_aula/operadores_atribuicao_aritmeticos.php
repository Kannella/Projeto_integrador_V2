<html>

<head>
    <meta charset="UTF-8">
    <title>Curso PHP</title>
</head>

<body>
    <?php
    // =
    // +, -, *, /, %

    $x = 10;
    $y = 8;
    //$x = $x + 5;
    //$x += 5 ;
    //$x -= $y;
    //$x /= $y;
    //$x *= $y;
    $x %= $y;
    echo $x;

    ?>
</body>

</html>