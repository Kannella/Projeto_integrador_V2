<html>

<head>
    <meta charset="UTF-8">
    <title>Curso PHP</title>
</head>

<body>
    <?php
    // $num = 7.5;
    // echo ceil($num); //arredonda para cima
    //echo floor($num); //arredonda para baixo
    // echo round($num) //arrendoda com base na fracao (.0 .4 -> para baixo) (.5 .9 -> para cima)
    // echo rand(10, 20); //gerar um falor aleatório (maior valor aleatório possível)
    // echo '<br />' . getrandmax(); //descobre o valor maximo que pode ser aleatorio a depender do sistema operacional
    
    echo sqrt(9); //raiz quadrada
    
    ?>
</body>

</html>